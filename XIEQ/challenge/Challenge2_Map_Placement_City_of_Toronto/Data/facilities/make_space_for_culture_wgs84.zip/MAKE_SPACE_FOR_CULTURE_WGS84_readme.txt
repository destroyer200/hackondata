MAKE_SPACE_FOR_CULTURE_WGS84_readme
 

Column name  (Description)
======================================
ADD_NUM = ADDRESS_NUMBER  (Street number)
LF_NAME = LINEAR_NAME_FULL  (Street Name)
ADDRESS = ADDRESS_FULL  (Full address)
POSTAL_CD = POSTAL_CODE  (POSTAL CODE)
CITY = CITY
X = X  (Easting in MTM NAD27 3 degree Projection)
Y = Y  (Northing in MTM NAD27 3 degree Projection)
LONGITUDE = LONGITUDE  (LONGITUDE = Longitude in WGS84 Coordinate System)
LATITUDE = LATITUDE  (Latitude in WGS84 Coordinate System)
FAC_NAM = FACILITY_NAME  (FACILITY NAME)
STE_FLR_UN = SUITE_FLOOR_UNIT  (SUITE FLOOR UNIT)
PERFRMANCE = PERFORMANCE  (Spaces in which performing arts (dance, music, theatre, etc.) creation or presentation takes place)
EXHBVISARTT = EXHIBITION_VISUAL_ARTS  (Spaces in which visual arts creation or presentation can take place, in addition to pure exhibition space.)
SCRN_BASSED = SCREEN_BASED  (Spaces for the production and presentation of multimedia screen-based arts including digital, )
LIBRARY = LIBRARY  (Toronto Public Library facility with physical space for cultural activity)
MULTIPURP = MULTIPURPOSE  (Spaces that are not purpose-built and can house a range of cultural activity across disciplines.)
HERITAGE = HERITAGE  (Facilities where heritage activity takes place (historical societies, archives, community museums etc.)
OWNERSHIP = OWNERSHIP  (OWNERSHIP)
OBJECTID = OBJECTID  (Unique system identifier)
